# -*- coding: utf-8 -*-

from france_taxbenefitsystem import FranceTaxBenefitSystem

CountryTaxBenefitSystem = FranceTaxBenefitSystem
